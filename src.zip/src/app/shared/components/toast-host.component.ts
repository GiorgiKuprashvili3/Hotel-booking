import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ToastService } from '../../core/ui/toast.service';

@Component({
  selector: 'lux-toast-host',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="toast-stack" role="region" aria-label="Notifications" aria-live="polite">
      @for (t of svc.toasts(); track t.id) {
        <div class="toast" [attr.data-tone]="t.tone" role="status">
          <mat-icon class="toast-icon" aria-hidden="true">{{ iconFor(t.tone) }}</mat-icon>
          <div class="toast-body">
            <div class="toast-title">{{ t.title }}</div>
            @if (t.message) { <div class="toast-message">{{ t.message }}</div> }
          </div>
          @if (t.action) {
            <button type="button"
                    class="toast-action"
                    (click)="t.action!.handler(); svc.dismiss(t.id)">
              {{ t.action.label }}
            </button>
          }
          <button type="button"
                  class="toast-close"
                  (click)="svc.dismiss(t.id)"
                  aria-label="Dismiss notification">
            <mat-icon>close</mat-icon>
          </button>
        </div>
      }
    </div>
  `,
  styles: [`
    .toast-stack {
      position: fixed;
      top: 16px; right: 16px;
      z-index: var(--z-toast);
      display: flex; flex-direction: column;
      gap: var(--space-2);
      max-width: min(420px, calc(100vw - 32px));
      pointer-events: none;
    }
    .toast {
      pointer-events: auto;
      display: flex; align-items: flex-start; gap: var(--space-3);
      padding: var(--space-3) var(--space-4);
      background: var(--surface);
      border: 1px solid var(--border);
      border-left: 4px solid var(--info);
      border-radius: var(--radius-md);
      box-shadow: var(--shadow-2);
      animation: slide-in 240ms cubic-bezier(0.4, 0, 0.2, 1);
    }
    .toast[data-tone="success"] { border-left-color: var(--success); }
    .toast[data-tone="warning"] { border-left-color: var(--warning); }
    .toast[data-tone="danger"]  { border-left-color: var(--danger);  }

    .toast-icon {
      flex-shrink: 0;
      font-size: 20px !important; width: 20px !important; height: 20px !important;
      color: var(--info);
      margin-top: 1px;
    }
    .toast[data-tone="success"] .toast-icon { color: var(--success); }
    .toast[data-tone="warning"] .toast-icon { color: var(--warning); }
    .toast[data-tone="danger"]  .toast-icon { color: var(--danger);  }

    .toast-body { flex: 1; min-width: 0; }
    .toast-title {
      font-size: var(--text-sm); font-weight: 600;
      color: var(--text);
    }
    .toast-message {
      font-size: var(--text-xs); color: var(--text-muted);
      margin-top: 2px; line-height: 1.45;
      overflow-wrap: anywhere;
    }

    .toast-action {
      align-self: center;
      background: transparent; border: none;
      color: var(--primary);
      font-size: var(--text-xs); font-weight: 600;
      padding: 4px 8px;
      border-radius: var(--radius-sm);
      cursor: pointer;
    }
    .toast-action:hover { background: var(--surface-2); }

    .toast-close {
      align-self: flex-start;
      background: transparent; border: none;
      width: 24px; height: 24px;
      display: flex; align-items: center; justify-content: center;
      border-radius: var(--radius-sm);
      color: var(--text-subtle);
      cursor: pointer;
    }
    .toast-close:hover { background: var(--surface-2); color: var(--text); }
    .toast-close mat-icon {
      font-size: 16px !important; width: 16px !important; height: 16px !important;
    }

    @keyframes slide-in {
      from { opacity: 0; transform: translateX(16px); }
      to   { opacity: 1; transform: translateX(0);   }
    }

    @media (prefers-reduced-motion: reduce) {
      .toast { animation: none; }
    }

    @media (max-width: 640px) {
      .toast-stack { top: 8px; right: 8px; left: 8px; max-width: none; }
    }
  `],
})
export class ToastHostComponent {
  svc = inject(ToastService);

  iconFor(tone: string): string {
    switch (tone) {
      case 'success': return 'check_circle';
      case 'warning': return 'warning';
      case 'danger':  return 'error';
      default:        return 'info';
    }
  }
}
